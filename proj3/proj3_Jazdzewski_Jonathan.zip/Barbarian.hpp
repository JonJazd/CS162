#ifndef Barbarian_HPP
#define Barbarian_HPP
#include "Character.hpp"

class Barbarian : public Character{
    public:
    Barbarian();
};

#endif