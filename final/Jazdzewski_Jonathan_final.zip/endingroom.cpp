#include <iostream>
#include "endingroom.hpp"
#include <string>

using std::string;
using std::cout;
using std::endl;

endingroom::endingroom():Space(){
    entryLine = "";
}
void endingroom::examine(){
    cout << "";
}
void endingroom::display(){
    cout << "";
}
void endingroom::showDirections(){
    cout << "";
}
void endingroom::action(){
    cout << "";
}